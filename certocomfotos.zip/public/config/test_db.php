<?php
require "db.php";
echo "DB CONNECTED OK";
